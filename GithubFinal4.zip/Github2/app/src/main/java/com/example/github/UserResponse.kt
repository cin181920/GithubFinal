package com.example.github

data class UserResponse(
    val items:ArrayList<User>
)
