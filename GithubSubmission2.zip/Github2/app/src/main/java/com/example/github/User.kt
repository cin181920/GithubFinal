package com.example.github

data class User(
    val login:String,
    val id:Int,
    val avatar_url:String


)
